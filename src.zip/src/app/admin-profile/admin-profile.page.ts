import { Component, OnInit } from '@angular/core';

@Component({
  standalone: false,  
  selector: 'app-admin-profile',
  templateUrl: './admin-profile.page.html',
  styleUrls: ['./admin-profile.page.scss'],
})
export class AdminProfilePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

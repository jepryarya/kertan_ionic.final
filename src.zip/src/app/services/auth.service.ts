// src/app/services/auth.service.ts
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private userRole: string | null = null;

  // Simulasi login (ganti sesuai backend nanti)
  login(username: string, password: string): boolean {
    if (username === 'admin') {
      this.userRole = 'admin';
      return true;
    } else if (username === 'user') {
      this.userRole = 'user';
      return true;
    }
    return false;
  }

  getRole(): string | null {
    return this.userRole;
  }
}

import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

@Component({
  standalone: false,
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {
  loginForm: FormGroup;
  showPassword = false;
  usernameFilled = false;
  passwordFilled = false;

  showFloatingCard = false;
  isBouncing = false;

  constructor(
    private fb: FormBuilder,
    private authService: AuthService, // tambahkan
    private router: Router            // tambahkan
  ) {
    this.loginForm = this.fb.group({
      username: [''],
      password: ['']
    });
  }

  ngOnInit() {}

  togglePasswordVisibility() {
    this.showPassword = !this.showPassword;
  }

  checkInput(field: 'username' | 'password') {
    const value = this.loginForm.get(field)?.value;
    this[`${field}Filled`] = !!value;
  }

  toggleFloatingCard() {
    this.isBouncing = true;
    setTimeout(() => {
      this.showFloatingCard = !this.showFloatingCard;
      this.isBouncing = false;
    }, 240);
  }

  closeFloatingCard() {
    this.showFloatingCard = false;
  }

  // FUNGSI LOGIN
  login() {
    const { username, password } = this.loginForm.value;
    if (this.authService.login(username, password)) {
      const role = this.authService.getRole();
      if (role === 'admin') {
        this.router.navigate(['/admin-menu']);
      } else if (role === 'user') {
        this.router.navigate(['/user-menu']);
      }
    } else {
      alert('Username atau password salah!');
    }
  }
}

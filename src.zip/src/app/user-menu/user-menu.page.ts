import { Component, OnInit } from '@angular/core';

@Component({
  standalone: false,
  selector: 'app-user-menu',
  templateUrl: './user-menu.page.html',
  styleUrls: ['./user-menu.page.scss'],
})
export class UserMenuPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  standalone: false,
  selector: 'app-admin-menu',
  templateUrl: './admin-menu.page.html',
  styleUrls: ['./admin-menu.page.scss'],
})
export class AdminMenuPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

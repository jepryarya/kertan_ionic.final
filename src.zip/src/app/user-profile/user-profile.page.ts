import { Component, OnInit } from '@angular/core';

@Component({
  standalone: false,  // This line is not necessary for Ionic pages, but included for consistency
  selector: 'app-user-profile',
  templateUrl: './user-profile.page.html',
  styleUrls: ['./user-profile.page.scss'],
})
export class UserProfilePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
